#ifndef _HEADERS_H
#define _HEADERS_H

#include <rExcel.h>
#include <String.h>
#include "HX711.h"
#include <Servo.h>

#include <Robojax_WCS.h>

/* setup() */
void setWorkingUnits();
char unitTorque, unitThrust, unitWeight, unitSpeed;
void getSafetyCutoffs();
float currentmin, currentmax, voltagemin, voltagemax, torquemin, torquemax, thrustmin, thrustmax, powermin, powermax;
int rpmmin, rpmmax;
enum MotorControlModes {StepTest=1, FixedThrustTest, Manual};
enum MotorControlModes MotorControlMode = Manual;
void getAutomaticTestParams(int);
long startTime = 0;

/* Current Sensor */
#define MODEL 11 //see list above
#define SENSOR_PIN A0 //pin for reading sensor
#define SENSOR_VCC_PIN 40 //pin for powring up the sensor
#define ZERO_CURRENT_LED_PIN 1 //zero current LED pin
#define ZERO_CURRENT_WAIT_TIME 5000 //wait for 5 seconds to allow zero current measurement
#define CORRECTION_VLALUE 164 //mA
#define MEASUREMENT_ITERATION 100
#define VOLTAGE_REFERENCE 5000.0 //5000mv is for 5V
#define BIT_RESOLUTION 10
#define DEBUT_ONCE true

Robojax_WCS sensor(
  MODEL, SENSOR_PIN, SENSOR_VCC_PIN,
  ZERO_CURRENT_WAIT_TIME, ZERO_CURRENT_LED_PIN,
  CORRECTION_VLALUE, MEASUREMENT_ITERATION, VOLTAGE_REFERENCE,
  BIT_RESOLUTION, DEBUT_ONCE
);

/* Load Cells */
#define LOADCELL_SCK_TL 6
#define LOADCELL_DOUT_TL 7
#define LOADCELL_SCK_TH 4
#define LOADCELL_DOUT_TH 5
#define LOADCELL_SCK_TR 8
#define LOADCELL_DOUT_TR 9
HX711 scale_tr, scale_th, scale_tl;

void calibLoadCell();
float CAL_FAC_TR = 0;
float CAL_FAC_TH = 0;
float CAL_FAC_TL = 0; //Calibration factor is verified using a known weight. If wrong, calibration_factor = wrong value*wrong cal_factor/known weight
float Avg_Load_tl, Avg_Load_tr, Avg_Load_th;

/* RPM Sensor */
#define RPM_SENSOR_PIN 2
void ISR_rpm();

/* ESC */
#define ESC_PIN 10
Servo servo;
void calibESC();

/* Excel */
int idx = 0; // index
int outputTiming = 1000; // packet sending timing in ms      important: this dermines the output timing
char value[32]; // written or read value
rExcel myExcel; // class for Excel data exchange
char sheets[10][15] = {
  "Welcome",
  "Setup",
  "Manual",
  "Automatic",
  "Data",
  "More Graphs",
  "Debug"
};

/* loop() */
void setMainRPMsensor();
int numPolesorTapes = 0;
void stepTest(int, int, int, int, int, int);
int escStart = 1000, minVal = 1000, maxVal = 2000, stepsQty = 5, settlTime = 2, stepTime = 5;
int step_pwm = escStart;
bool upDone = 0;
long timeStepStart;

void fixedThrustTest();

long sensor_getRPM();
void calc();
void logCurrentData();
void logData();
float convertUnit(float, char, char);

float Load_tl = 0, Load_tr = 0, Load_th = 0, Torque = 0, Thrust = 0;
float MotorSpeed, MechanicalPower, ElectricalPower, MotorEfficiency, PropEfficiency, SystemEfficiency;
float Voltage = 12;
float Current, zeroCurrent;
int RPM = 0;

/* RPM sensor interrupt */
volatile unsigned long t_pulse_started_volatile = 0; 
volatile unsigned long t_pulse_duration_volatile = 0;
unsigned long t_pulse_started = 0;
unsigned long t_pulse_duration = 0;

long rpm_sum = 0; 
long rpm_reading[100];
long rpm_average = 0;
byte n_max = 0;
byte n = 0;
int count1 = 0;
volatile bool timeout = 1; 
volatile bool newpulse = 0;

#endif