#ifndef _HEADERS_H
#define _HEADERS_H

#include <rExcel.h>

#include "HX711.h"

#include <Servo.h>

#define pi 3.14159

int samplesAvg;
int idx = 0; // index
int outputTiming = 1000; // packet sending timing in ms      important: this dermines the output timing
char value[32]; // written or read value
rExcel myExcel; // class for Excel data exchange
char sheets[10][15] = {
  "Welcome",
  "Setup",
  "Utilities",
  "Safety Cutoffs",
  "Manual",
  "Automatic",
  "Data",
  "More Graphs",
  "Debug"
};
const int LOADCELL_SCK_TR = 2;
const int LOADCELL_DOUT_TR = 3;
const int LOADCELL_SCK_TH = 4;
const int LOADCELL_DOUT_TH = 5;
const int LOADCELL_SCK_TL = 8;
const int LOADCELL_DOUT_TL = 9;
Servo servo;
float CAL_FAC_TR;
float CAL_FAC_TH;
float CAL_FAC_TL; //Calibration factor is verified using a known weight. If wrong, calibration_factor = wrong value*wrong cal_factor/known weight
HX711 scale_tr, scale_th, scale_tl;
float Load_tl, Load_tr, Load_th, Load_tl_1, Load_tl_2, Load_tl_3, Load_tl_4, Load_tl_5, Load_tr_1, Load_tr_2, Load_tr_3, Load_tr_4, Load_tr_5, Torque, Thrust;
float Load_th_1, Load_th_2, Load_th_3, Load_th_4, Load_th_5, MotorSpeed, MechanicalPower, ElectricalPower = 2, MotorEfficiency, PropEfficiency, SystemEfficiency;
float Voltage = 5;
double Current;
int RPM = 1;
char baud[7];
float Avg_Load_tl, Avg_Load_tr, Avg_Load_th;
int baudRate;
char unitTorque, unitThrust, unitWeight, unitSpeed;
char logFileAdd[20];

#include <Wire.h>

#include <Robojax_WCS.h>

#define MODEL 11 //see list above
#define SENSOR_PIN A0 //pin for reading sensor
#define SENSOR_VCC_PIN 14 //pin for powring up the sensor
#define ZERO_CURRENT_LED_PIN 2 //zero current LED pin

#define ZERO_CURRENT_WAIT_TIME 5000 //wait for 5 seconds to allow zero current measurement
#define CORRECTION_VLALUE 164 //mA
#define MEASUREMENT_ITERATION 100
#define VOLTAGE_REFERENCE 5000.0 //5000mv is for 5V
#define BIT_RESOLUTION 10
#define DEBUT_ONCE true

Robojax_WCS sensor(
  MODEL, SENSOR_PIN, SENSOR_VCC_PIN,
  ZERO_CURRENT_WAIT_TIME, ZERO_CURRENT_LED_PIN,
  CORRECTION_VLALUE, MEASUREMENT_ITERATION, VOLTAGE_REFERENCE,
  BIT_RESOLUTION, DEBUT_ONCE
);

void setUnits();
void setLogFile();
void calc();
void logCurrentData();
void logData();
float convertUnit(float data, char unitNo, char Quantity);
float rpm();
int elec_rpm();
void calibLoadCell();
void calibESC();
void setBaudRate();
#endif
