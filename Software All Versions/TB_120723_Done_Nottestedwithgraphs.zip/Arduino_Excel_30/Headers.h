#ifndef _HEADERS_H
#define _HEADERS_H

#include <rExcel.h>
#include <String.h>
#include "HX711.h"

#include <Servo.h>

#define pi 3.14159

int samplesAvg;
int idx = 0; // index
int outputTiming = 1000; // packet sending timing in ms      important: this dermines the output timing
char value[32]; // written or read value
rExcel myExcel; // class for Excel data exchange
char sheets[10][15] = {
  "Welcome",
  "Setup",
  "Utilities",
  "Safety Cutoffs",
  "Manual",
  "Automatic",
  "Data",
  "More Graphs",
  "Debug"
};
const int LOADCELL_SCK_TL = 6;
const int LOADCELL_DOUT_TL = 7;
const int LOADCELL_SCK_TH = 4;
const int LOADCELL_DOUT_TH = 5;
const int LOADCELL_SCK_TR = 8;
const int LOADCELL_DOUT_TR = 9;

const byte RPMsensor = 2;

byte Mode=5;
int startTime = 0;
Servo servo;
float CAL_FAC_TR = 0;
float CAL_FAC_TH = 0;
float CAL_FAC_TL = 0; //Calibration factor is verified using a known weight. If wrong, calibration_factor = wrong value*wrong cal_factor/known weight
HX711 scale_tr, scale_th, scale_tl;
float Load_tl = 0, Load_tr = 0, Load_th = 0, Torque = 0, Thrust = 0;
float MotorSpeed, MechanicalPower, ElectricalPower, MotorEfficiency, PropEfficiency, SystemEfficiency;
float Voltage = 12;
float Current, zeroCurrent;
float currentmin, currentmax, voltagemin, voltagemax, torquemin, torquemax, thrustmin, thrustmax, powermin, powermax;
int rpmmin, rpmmax;
int RPM = 0;
char baud[7];
float Avg_Load_tl, Avg_Load_tr, Avg_Load_th;
int baudRate;
char unitTorque, unitThrust, unitWeight, unitSpeed;
char logFileAdd[20];
int numPoles = 0, numTapes = 0;
#include <Wire.h>

#include <Robojax_WCS.h>

#define MODEL 11 //see list above
#define SENSOR_PIN A0 //pin for reading sensor
#define SENSOR_VCC_PIN 40 //pin for powring up the sensor
#define ZERO_CURRENT_LED_PIN 1 //zero current LED pin

#define ZERO_CURRENT_WAIT_TIME 5000 //wait for 5 seconds to allow zero current measurement
#define CORRECTION_VLALUE 164 //mA
#define MEASUREMENT_ITERATION 100
#define VOLTAGE_REFERENCE 5000.0 //5000mv is for 5V
#define BIT_RESOLUTION 10
#define DEBUT_ONCE true

Robojax_WCS sensor(
  MODEL, SENSOR_PIN, SENSOR_VCC_PIN,
  ZERO_CURRENT_WAIT_TIME, ZERO_CURRENT_LED_PIN,
  CORRECTION_VLALUE, MEASUREMENT_ITERATION, VOLTAGE_REFERENCE,
  BIT_RESOLUTION, DEBUT_ONCE
);

volatile unsigned long t_pulse_started_volatile = 0; // Sensor1
volatile unsigned long t_pulse_duration_volatile = 0;
unsigned long t_pulse_started = 0;
unsigned long t_pulse_duration = 0;

long rpm_sum = 0; // Sensor1
long rpm_reading[100];
long rpm_average = 0;
byte n_max = 0;
byte n = 0;
int count1 = 0;
volatile bool timeout = 1; // Sensor1
volatile bool newpulse = 0;

void setUnits();
void setLogFile();
void calc();
void logCurrentData();
void logData();
float convertUnit(float data, char unitNo, char Quantity);

void calibLoadCell();
void calibESC();
void setBaudRate();
void sensor_rpm();
void ISR_rpm();
void rampTest();
void stepTest();
void getSafetyCutoffs();
#endif
